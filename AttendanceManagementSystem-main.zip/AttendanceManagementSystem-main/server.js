const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 4000;
const MONGODB_URI =
  process.env.MONGODB_URI ||
  "mongodb+srv://vamsi_db_AMS:Vsvg%40database1@cluster0.4glo7wg.mongodb.net/attendance_manager?retryWrites=true&w=majority&appName=Cluster0";

app.use(cors({ origin: "*"}));
app.use(express.json());

mongoose
  .connect(MONGODB_URI, {
    serverSelectionTimeoutMS: 10000,
  })
  .then(() => console.log("✓ MongoDB connected"))
  .catch((err) => {
    console.error("✗ MongoDB connection error", err);
    process.exit(1);
  });

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true, lowercase: true },
    studentId: { type: String, trim: true },
    className: { type: String, trim: true },
    role: { type: String, enum: ["student", "teacher"], required: true },
    passwordHash: { type: String, required: true },
  },
  { timestamps: true }
);

userSchema.index({ email: 1, role: 1 }, { unique: true });

const User = mongoose.model("User", userSchema);

const sanitizeUser = (user) => {
  const json = user.toObject();
  delete json.passwordHash;
  delete json.__v;
  return json;
};

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password, role, studentId, className } = req.body;
    if (!name || !email || !password || !role) {
      return res.status(400).json({ message: "Missing required fields." });
    }

    const normalizedRole = String(role).toLowerCase();
    if (!["student", "teacher"].includes(normalizedRole)) {
      return res.status(400).json({ message: "Invalid role supplied." });
    }

    const existing = await User.findOne({ email: email.toLowerCase(), role: normalizedRole });
    if (existing) {
      return res.status(409).json({ message: "User already registered for this role." });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({
      name,
      email: email.toLowerCase(),
      role: normalizedRole,
      studentId: normalizedRole === "student" ? studentId : undefined,
      className,
      passwordHash,
    });

    res.status(201).json({ user: sanitizeUser(user) });
  } catch (error) {
    console.error("Register error:", error);
    res.status(500).json({ message: "Registration failed." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password, role } = req.body;
    if (!email || !password || !role) {
      return res.status(400).json({ message: "Missing credentials." });
    }

    const normalizedRole = String(role).toLowerCase();
    const user = await User.findOne({ email: email.toLowerCase(), role: normalizedRole });
    if (!user) {
      return res.status(401).json({ message: "Invalid email or role." });
    }

    const passwordMatch = await bcrypt.compare(password, user.passwordHash);
    if (!passwordMatch) {
      return res.status(401).json({ message: "Incorrect password." });
    }

    res.json({ user: sanitizeUser(user) });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Login failed." });
  }
});

app.use((req, res) => {
  res.status(404).json({ message: "Endpoint not found." });
});

app.listen(PORT, () => {
  console.log(`API server running on http://localhost:${PORT}`);
});

